import gym

env = gym.make("Taxi-v2").env

env.render()
